Contributors
============

feedparser is written and maintained by `Kurt McKee <http://kurtmckee.org/>`_.
It was originally written by Mark Pilgrim.

Many people have contributed to feedparser. They are listed below in
alphabetical order by last name.

When submitting patches, please add your name to the list below. If you have
previously contributed to feedparser and are not credited below, please open a
bug report!

* `John Beimler <http://john.beimler.org/>`_
* `François Boulogne <http://www.sciunto.org/>`_
* `Jason Diamond <http://injektilo.org/>`_
* `Fazal Majid <https://majid.info/blog/>`_
* `Kevin Marks <http://epeus.blogspot.com/>`_
* `Nik Nyby <http://nikolas.us.to/>`_
* `Ade Oshineye <http://blog.oshineye.com/>`_
* `Martin Pool <http://sourcefrog.net/>`_
* `Sam Ruby <http://intertwingly.net/>`_
* `Bernd Schlapsi <https://github.com/brot>`_
* `Aaron Swartz <http://www.aaronsw.com/>`_
* `Jakub Wilk <http://jwilk.net/>`_
