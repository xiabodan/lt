.. _reference.feed.language:

:py:attr:`feed.language`
========================

The primary language of the feed.


.. rubric:: Comes from

* /atom03:feed/@xml:lang
* /atom10:feed/@xml:lang
* /rdf:RDF/rdf:channel/dc:language
* /rss/channel/dc:language
* /rss/channel/language
