Changes in version 4.0.1
========================




:program:`Universal Feed Parser` 4.0.1 was released on December 24, 2005.

- bug fixes for :program:`Python` 2.1 compatibility.